require(shiny)
require(RMySQL)
require(shinydashboard)
require(shinyWidgets)
require(dplyr)
require(ggplot2)
require(tibbletime)
require(tidyverse)
require(DT)
require(glmnet)
require(caret)
require(echarts4r)
require(leaflet)
require(shinyalert)
require(googlesheets4)
require(rsconnect)

app_title <- "My Heart APP  "

createSelectInput <- function(inputId, label, choices) {
  return(
    column(
      width = 10,
      selectInput(
        inputId = inputId,
        label = label,
        choices = choices,
        width = 1200
      )
    )
  )
}
createSliderInput <- function(inputId, label, min, max, value) {
  return(
    column(
      width = 10,
      sliderInput(
        inputId = inputId,
        label = label,
        min = min,
        max = max,
        value = value,
        width = 1200
      )
    )
  )
}
frow1 <- fluidRow(
  #fluidRow for dashboard
  h2("Overview on health condition"),
  valueBoxOutput("AvgBP")
  ,valueBoxOutput("AvgBMI")
  ,valueBoxOutput("Avgglucose")
  ,valueBoxOutput("Avgcalintake")
  ,valueBoxOutput("Avgcalburnt")
  ,valueBoxOutput("RiskHeartAttackValue")
)
frow2 <- fluidRow(
  title = app_title,
  
  h2(app_title),
  
  h3("Parameters", style = "margin-bottom: 24px"),
  
  
  createSelectInput(
    inputId = "Smoking",
    label = h3("Smoking"),
    choices = c("Yes" = "Yes", "No" = "No")
  ),
  createSelectInput(
    inputId = "AlcoholDrinking",
    label = h3("AlcoholDrinking"),
    choices = c("Yes" = "Yes", "No" = "No")
  ),
  createSelectInput(
    inputId = "Stroke",
    label = h3("Stroke"),
    choices = c("Yes" = "Yes", "No" = "No")
  ),
  createSelectInput(
    inputId = "DiffWalking",
    label = h3("DiffWalking"),
    choices = c("Yes" = "Yes", "No" = "No")
  ),
  createSelectInput(
    inputId = "Sex",
    label = h3("Sex"),
    choices = c("Female" = "Female", "Male" = "Male")
  ),
  createSelectInput(
    inputId = "AgeCategory",
    label = h3("AgeCategory"),
    choices = c("50-54" = "50-54", 
                "60-64" = "60-64",
                "65-69" = "65-69",
                "70-74" = "70-74",
                "75-79" = "75-79",
                "80 or older" = "80 or older",
                "(Other)" = "(Other)")
  ),
  createSelectInput(
    inputId = "Race",
    label = h3("Race"),
    choices = c("Asian" = "Asian", 
                "Black" = "Black",
                "Hispanic" = "Hispanic",
                "American Indian/Alaskan Native" = "American Indian/Alaskan Native",
                "White" = "White",
                "Other" = "Other")
  ),
  createSelectInput(
    inputId = "Diabetic",
    label = h3("Diabetic"),
    choices = c("Yes" = "Yes", "No" = "No")
  ),
  createSelectInput(
    inputId = "PhysicalActivity",
    label = h3("PhysicalActivity"),
    choices = c("Yes" = "Yes", "No" = "No")
  ),
  createSelectInput(
    inputId = "GenHealth",
    label = h3("GenHealth"),
    choices = c("Excellent" = "Excellent", 
                "Very good" = "Very good",
                "Good" = "Good",
                "Fair" = "Fair",
                "Poor" = "Poor")
  ),
  createSelectInput(
    inputId = "Asthma",
    label = h3("Asthma"),
    choices = c("Yes" = "Yes", "No" = "No")
  ),
  createSelectInput(
    inputId = "KidneyDisease",
    label = h3("KidneyDisease"),
    choices = c("Yes" = "Yes", "No" = "No")
  ),
  createSelectInput(
    inputId = "SkinCancer",
    label = h3("SkinCancer"),
    choices = c("Yes" = "Yes", "No" = "No")
  ),
  createSliderInput(
    inputId = "PhysicalHealth",
    label = h3("PhysicalHealth"),
    min = 0,
    max = 30,
    value = 8
  ),
  createSliderInput(
    inputId = "MentalHealth",
    label = h3("MentalHealth"),
    min = 0,
    max = 30,
    value = 8
  ),
  createSliderInput(
    inputId = "height1",
    label = h3("height (cm)"),
    min = 120,
    max = 200,
    value = 165
  ),
  createSliderInput(
    inputId = "weight1",
    label = h3("weight (kg)"),
    min = 40,
    max = 100,
    value = 50
  ),
  createSliderInput(
    inputId = "SleepTime",
    label = h3("SleepTime"),
    min = 0,
    max = 24,
    value = 8
  ),
  br(),
  
  fluidRow(
    style = "margin-bottom: 24px",
    
    column(
      width = 12,
      align = "middle",
      
      actionButton(
        inputId = "submit1",
        label = h4("submit"),
        width=200
      )
    )
    
  )
)
frow3 <- fluidRow(
  h2("Daily Tracker"),
  column(
    width=10,
  numericInput("glucosereading", label = h3("Glucose Reading (mg/dL or mmol/L)"),
               NULL, min = 2, max = 300, step = 0.1,width = 1200)),
  createSliderInput(
    inputId = "systolic",
    label = h3("Systolic  (mmHg)"),
    min = 50,
    max = 300,
    value = 125
  ),
  createSliderInput(
    inputId = "diastolic",
    label = h3("Diastolic (mmHg)"),
    min = 10,
    max = 150,
    value = 80
  ),
  createSliderInput(
    inputId = "caloriesintake",
    label = h3("Today's Calories Intake  (kcal)"),
    min = 0,
    max = 10000,
    value = 5000
  )
  ,
  createSliderInput(
    inputId = "caloriesburnt",
    label = h3("Today's Calories Burnt (kcal)"),
    min = 0,
    max = 10000,
    value = 2000
  )
  ,
  createSliderInput(
    inputId = "weight2",
    label = h3("weight (kg)"),
    min = 40,
    max = 100,
    value = 50
  )
  ,
  createSliderInput(
    inputId = "height2",
    label = h3("Height (cm)"),
    min = 50,
    max = 210,
    value = 165
  ),
  
  br(),
  fluidRow(
    style = "margin-bottom: 24px",
    
    column(
      width = 12,
      align = "middle",
      
      actionButton(
        inputId = "submit2",
        label = h4("submit"),
        width=200
      )
    )
    
  )
)
frow4 <- fluidRow(
  tabPanel("Overview", icon=icon("fas fa-file-alt"),
           
           fluidPage(
             
             fluidRow(column(width = 12,h2(strong("Overview")))),
             
             
             HTML("
                               <div style='background-color:white; padding: 5px 10px; border-radius: 5px; margin-bottom: 50px;'>
                                  <h4><i class=' fas fa-grip-vertical fa-fw'></i><b> Dashboard </b></h4>
                                  <p> This page provides one glance view on health insights and provide potential risk on overall health condition. </p>
                                  <br/>
                                  <h4><i class=' fas fa-clipboard-list fa-fw'></i><b> Profile </b></h4>
                                  <p> This page requires the user to enter personal information and habits.<br>
                                      <li>Smoking : Have you smoked at least 100 cigarettes in your entire life? ( The answer Yes or No ).</li>
                                      <li>AlcoholDrinking : Heavy drinkers (adult men having more than 14 drinks per week and adult women having more than 7 drinks per week.</li>
                                      <li>Stroke : (Ever told) (you had) a stroke? </li>
                                      <li>PhysicalHealth : Now thinking about your physical health, which includes physical illness and injury, for how many days during the past 30 days was your physical health not good? (0-30 days).</li>
                                      <li>MentalHealth : Thinking about your mental health, for how many days during the past 30 days was your mental health not good? (0-30 days).</li>
                                      <li>DiffWalking : Do you have serious difficulty walking or climbing stairs?</li>
                                      <li>Sex : Are you male or female?</li>
                                      <li>AgeCategory: Fourteen-level age category.</li>
                                      <li>Race : Imputed race/ethnicity value.</li>
                                      <li>Diabetic : (Ever told) (you had) diabetes?</li>
                                      <li>PhysicalActivity : Adults who reported doing physical activity or exercise during the past 30 days other than their regular job.</li>
                                      <li>GenHealth : Would you say that in general your health is...</li>
                                      <li>SleepTime : On average, how many hours of sleep do you get in a 24-hour period?</li></p>
                                     <br/>
                                  <h4><i class=' fas fa-info fa-fw'></i><b> Daikt Tracker </b></h4>
                                  <p> Daily tracking and recording of all heart vitals signs and health information such as systolic blood pressure, diastolic blood pressure, calorie intake, calories burned, weight and height</p>
                                  <br/>
                                  <h4><i class=' fas fa-file-alt fa-fw'></i><b> Documentation </b></h4>
                                  <p> This page contains the overview of my heart health application, a user guide for users using this application.</p>
                                </div>
                               "),
             
             h3('How to Use The App?'),
             
             tags$ol(
               tags$li('Click', a('https://sunyu17194849.shinyapps.io/myheartApp/', target = '_blank'), 'for people who wants to manage heart health to improve their overall health condition.'),
               
               tags$li('The landing page is a dashboard that indicate the potential risk on overall health condition over the last 7 days.'),
               tags$img(src = 'https://drive.google.com/uc?export=view&id=19AWTma-u0znKAOFE1HWdYeU6KrGK3nie'),
               
               tags$li('Click on Profile page, Selection of Smoking, AlcoholDrinking, Stroke, DiffWalking,Sex,AgeCategory,Race,Diabetic,PhysicalActivity,GenHealth, and SleepTime in the right panel.'),
               tags$img(src = 'https://drive.google.com/uc?export=view&id=1NszK2pCSESUr2fFe9LjFb5ZeCcOP0n0y'),
               
               tags$li('Then scale PhysicalHealth, MentalHealth, height, Weight and SleepTime within the range.'),
               tags$img(src = 'https://drive.google.com/uc?export=view&id=1o0CLQiAR69PgIfUQSHFetpoTznc1xqb8'),
               
               tags$li('Finally, click Submit to check whether the current user has a high or low risk of heart disease.Below figure shown this user has a low heart disease risk'),
               tags$img(src = 'https://drive.google.com/uc?export=view&id=1XHB1asjqqu-wwp-O5QRhUwThXqCkWsQn'),
               
               
               tags$li('Click on Daily tracker page to select Glucose Reading (mg/dL or mmol/L), then sacle systolic blood pressure, diastolic blood pressure, calorie intake,calories burned, weight and height'),
               tags$img(src = 'https://drive.google.com/uc?export=view&id=1DqhfTzQa7JPVrmkeUuFp3eNLOcVfurIs'),
               
               tags$li('Then click on submit button to save daily health information for tracking.'),
               tags$img(src = 'https://drive.google.com/uc?export=view&id=1Sp99hkw4nJrvxHhm2eWtp0Nde2gtCgBa'),
               
               tags$li('Click on Documentation page for details on how to use, datasets, application links.'),
               
               
               
               
             ),
             
             fluidRow(column(width=11, h2(strong("Data")))),
             fluidRow(column(width=11, HTML("<p> The dataset 'Personal Key Indicators of Heart Disease' is obtained from Kaggle."))),
             
             br(),
             fluidRow(column(width=11, h2(strong("Source Code")))),
             fluidRow(column(width=11, tags$a(href = "https://github.com/SyafiqNaqiuddin99/MyHeartApp", "Github Link"))),
             
             br(),
             fluidRow(column(width=11, h2(strong("Shiny App")))),
             fluidRow(column(width=11, tags$a(href = "https://sunyu17194849.shinyapps.io/myheartApp/", "App Link"))),
             
             br(),
             
             
             fluidRow(column(width=11, h2(strong("References")))),
             fluidRow(column(width=11, HTML("<p>Pytlak, K. (2020). Personal Key Indicators of Heart Disease.Kaggle."),tags$a(href = "https://www.kaggle.com/datasets/kamilpytlak/personal-key-indicators-of-heart-disease", "https://www.kaggle.com/datasets/kamilpytlak/personal-key-indicators-of-heart-disease"))), 
             
             br(),
             
             fluidRow(column(width = 12,h2(strong("Authors")))),
             fluidRow(column(width = 12,HTML("<p> by Group 10"))),
             fluidRow(column(width = 12,HTML("<p>1. Muhammad Syafiq Naqiuddin Bin Nil Amri(S2146201)"))),         
             fluidRow(column(width = 12,HTML("<p>2. Lim poh Sze (17082915/2)"))),         
             fluidRow(column(width = 12,HTML("<p>3. Chen Bao Gang (17186722/2)"))),      
             fluidRow(column(width = 12,HTML("<p>4. Sun Yu(17194849/2)"))),
             fluidRow(column(width = 12,HTML("<p>5. Lim Shi Jun (17113677/2)")))                        
             
           ))
)


#Sidebar content of the dashboard
sidebar <- dashboardSidebar(
  
  #Three tabs on the dashboard
  sidebarMenu(
    menuItem("Dashboard", tabName = "dashboard", icon = icon("grip-vertical")),
    menuItem("profile", tabName = "profile", icon = icon("clipboard-list")),
    menuItem("Daily Tracker",tabName = "tracker", icon = icon("info")),
    menuItem("Documentation",tabName = "Documentation", icon = icon("fas fa-file-alt"))
  )
)
# combine the fluid rows to make the body
body <- dashboardBody(
  tabItems(
    tabItem(tabName="dashboard",frow1),
    tabItem(tabName="profile", frow2),
    tabItem(tabName="tracker", frow3),
    tabItem(tabName="Documentation", frow4)
    
  )
)
#Dashboard title
header <- dashboardHeader(title = "MyHealth App")
dashboardPage(title = 'MyHeart App', header, sidebar, body, skin='blue')

