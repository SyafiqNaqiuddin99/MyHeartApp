require(shiny)
require(shinydashboard)
require(shinyWidgets)
require(dplyr)
require(ggplot2)
require(tibbletime)
require(tidyverse)
require(DT)
require(echarts4r)
require(leaflet)
require(shinyalert)
require(googlesheets4)
require(rsconnect)
require(shinytheme)

app_title <- "My Heart APP  "

createSelectInput <- function(inputId, label, choices) {
  return(
    column(
      width = 10,
      selectInput(
        inputId = inputId,
        label = label,
        choices = choices,
        width = 1200
      )
    )
  )
}
createSliderInput <- function(inputId, label, min, max, value) {
  return(
    column(
      width = 10,
      sliderInput(
        inputId = inputId,
        label = label,
        min = min,
        max = max,
        value = value,
        width = 1200
      )
    )
  )
}
frow1 <- fluidRow(
  #fluidRow for dashboard
  h2("Overview on health condition"),
  valueBoxOutput("AvgBP")
  ,valueBoxOutput("AvgBMI")
  ,valueBoxOutput("Avgglucose")
  ,valueBoxOutput("Avgcalintake")
  ,valueBoxOutput("Avgcalburnt")
  ,valueBoxOutput("RiskHeartAttackValue")
)
frow2 <- fluidRow(
  title = app_title,
  
  h2(app_title),
  
  h3("Parameters", style = "margin-bottom: 24px"),
  
  
  createSelectInput(
    inputId = "Smoking",
    label = h3("Smoking"),
    choices = c("Yes" = "Yes", "No" = "No")
  ),
  createSelectInput(
    inputId = "AlcoholDrinking",
    label = h3("AlcoholDrinking"),
    choices = c("Yes" = "Yes", "No" = "No")
  ),
  createSelectInput(
    inputId = "Stroke",
    label = h3("Stroke"),
    choices = c("Yes" = "Yes", "No" = "No")
  ),
  createSelectInput(
    inputId = "DiffWalking",
    label = h3("DiffWalking"),
    choices = c("Yes" = "Yes", "No" = "No")
  ),
  createSelectInput(
    inputId = "Sex",
    label = h3("Sex"),
    choices = c("Female" = "Female", "Male" = "Male")
  ),
  createSelectInput(
    inputId = "AgeCategory",
    label = h3("AgeCategory"),
    choices = c("50-54" = "50-54", 
                "60-64" = "60-64",
                "65-69" = "65-69",
                "70-74" = "70-74",
                "75-79" = "75-79",
                "80 or older" = "80 or older",
                "(Other)" = "(Other)")
  ),
  createSelectInput(
    inputId = "Race",
    label = h3("Race"),
    choices = c("Asian" = "Asian", 
                "Black" = "Black",
                "Hispanic" = "Hispanic",
                "American Indian/Alaskan Native" = "American Indian/Alaskan Native",
                "White" = "White",
                "Other" = "Other")
  ),
  createSelectInput(
    inputId = "Diabetic",
    label = h3("Diabetic"),
    choices = c("Yes" = "Yes", "No" = "No")
  ),
  createSelectInput(
    inputId = "PhysicalActivity",
    label = h3("PhysicalActivity"),
    choices = c("Yes" = "Yes", "No" = "No")
  ),
  createSelectInput(
    inputId = "GenHealth",
    label = h3("GenHealth"),
    choices = c("Excellent" = "Excellent", 
                "Very good" = "Very good",
                "Good" = "Good",
                "Fair" = "Fair",
                "Poor" = "Poor")
  ),
  createSelectInput(
    inputId = "Asthma",
    label = h3("Asthma"),
    choices = c("Yes" = "Yes", "No" = "No")
  ),
  createSelectInput(
    inputId = "KidneyDisease",
    label = h3("KidneyDisease"),
    choices = c("Yes" = "Yes", "No" = "No")
  ),
  createSelectInput(
    inputId = "SkinCancer",
    label = h3("SkinCancer"),
    choices = c("Yes" = "Yes", "No" = "No")
  ),
  createSliderInput(
    inputId = "PhysicalHealth",
    label = h3("PhysicalHealth"),
    min = 0,
    max = 30,
    value = 8
  ),
  createSliderInput(
    inputId = "MentalHealth",
    label = h3("MentalHealth"),
    min = 0,
    max = 30,
    value = 8
  ),
  createSliderInput(
    inputId = "height1",
    label = h3("height (cm)"),
    min = 120,
    max = 200,
    value = 165
  ),
  createSliderInput(
    inputId = "weight1",
    label = h3("weight (kg)"),
    min = 40,
    max = 100,
    value = 50
  ),
  createSliderInput(
    inputId = "SleepTime",
    label = h3("SleepTime"),
    min = 0,
    max = 24,
    value = 8
  ),
  br(),
  
  fluidRow(
    style = "margin-bottom: 24px",
    
    column(
      width = 12,
      align = "middle",
      
      actionButton(
        inputId = "submit1",
        label = h4("submit"),
        width=200
      )
    )
    
  )
)
frow3 <- fluidRow(
  h2("Daily Tracker"),
  column(
    width=10,
  numericInput("glucosereading", label = h3("Glucose Reading (mg/dL or mmol/L)"),
               NULL, min = 2, max = 300, step = 0.1,width = 1200)),
  createSliderInput(
    inputId = "systolic",
    label = h3("Systolic  (mmHg)"),
    min = 50,
    max = 300,
    value = 125
  ),
  createSliderInput(
    inputId = "diastolic",
    label = h3("Diastolic (mmHg)"),
    min = 10,
    max = 150,
    value = 80
  ),
  createSliderInput(
    inputId = "caloriesintake",
    label = h3("Today's Calories Intake  (kcal)"),
    min = 0,
    max = 10000,
    value = 5000
  )
  ,
  createSliderInput(
    inputId = "caloriesburnt",
    label = h3("Today's Calories Burnt (kcal)"),
    min = 0,
    max = 10000,
    value = 2000
  )
  ,
  createSliderInput(
    inputId = "weight2",
    label = h3("weight (kg)"),
    min = 40,
    max = 100,
    value = 50
  )
  ,
  createSliderInput(
    inputId = "height2",
    label = h3("Height (cm)"),
    min = 50,
    max = 210,
    value = 165
  ),
  
  br(),
  fluidRow(
    style = "margin-bottom: 24px",
    
    column(
      width = 12,
      align = "middle",
      
      actionButton(
        inputId = "submit2",
        label = h4("submit"),
        width=200
      )
    )
    
  )
)
#Sidebar content of the dashboard
sidebar <- dashboardSidebar(
  
  #Three tabs on the dashboard
  sidebarMenu(
    menuItem("Dashboard", tabName = "dashboard", icon = icon("grip-vertical")),
    menuItem("profile", tabName = "profile", icon = icon("clipboard-list")),
    menuItem("Daily Tracker",tabName = "tracker", icon = icon("info"))
  )
)
# combine the fluid rows to make the body
body <- dashboardBody(
  tabItems(
    tabItem(tabName="dashboard",frow1),
    tabItem(tabName="profile", frow2),
    tabItem(tabName="tracker", frow3)
  )
)
#Dashboard title
header <- dashboardHeader(title = "MyHealth App")
dashboardPage(title = 'MyHeart App', header, sidebar, body, skin='blue')

