


model <- readRDS("model.rds","rb")
BMI <- function(weight, height) {
  return(weight / (height/100)^2)
}
createPersonalDataFrame <- function(input) {
  return(
    data.frame(
      HeartDisease="",
      BMI = round(BMI(input$weight2,input$height2),1),
      Smoking = input$Smoking,
      AlcoholDrinking = input$AlcoholDrinking,
      Stroke = input$Stroke,
      PhysicalHealth=input$PhysicalHealth,
      MentalHealth=input$MentalHealth,
      DiffWalking=input$DiffWalking,
      Sex = input$Sex,
      AgeCategory = input$AgeCategory,
      Race = input$Race,
      Diabetic = input$Diabetic,
      PhysicalActivity = input$PhysicalActivity,
      GenHealth = input$GenHealth,
      SleepTime=input$SleepTime,
      Asthma = input$Asthma,
      KidneyDisease = input$KidneyDisease,
      SkinCancer = input$SkinCancer
    )
  )
}
createDataFrame <- function(input) {
  return(
    data.frame(
      date = as.Date(Sys.Date()),
      systolic = input$systolic,
      diastolic = input$diastolic,
      glucosereading = input$glucosereading,
      bmi = round(BMI(input$weight2,input$height2),1),
      caloriesintake = input$caloriesintake,
      caloriesburnt = input$caloriesburnt
    )
  )
}
updateFactors <- function(df) {
  df$Smoking <- as.factor(df$Smoking)
  df$AlcoholDrinking <- as.factor(df$AlcoholDrinking)
  df$Stroke <- as.factor(df$Stroke)
  df$DiffWalking <- as.factor(df$DiffWalking)
  df$Sex <- as.factor(df$Sex)
  df$AgeCategory <- as.factor(df$AgeCategory)
  df$Race <- as.factor(df$Race)
  df$Diabetic <- as.factor(df$Diabetic)
  df$PhysicalActivity <- as.factor(df$PhysicalActivity)
  df$GenHealth <- as.factor(df$GenHealth)
  df$Asthma <- as.factor(df$Asthma)
  df$KidneyDisease <- as.factor(df$KidneyDisease)
  df$SkinCancer <- as.factor(df$SkinCancer)
  
  return(df)
}
function(input, output,session) { 
  gs4_auth(email =gargle::gargle_oauth_cache())
  patientdata <- read_sheet("https://docs.google.com/spreadsheets/d/1mZd4fmFSJR_tXQU_DBz5MWodmyu7TzrysYnC1vKkEzU/edit#gid=0")
  patient <- as.data.frame(patientdata)
  PatientRisk<-read_sheet("https://docs.google.com/spreadsheets/d/12SCOAznYC0QYxmBgSsT7Fcz0XdtK_jo9NIKb8JtfBuY/edit?usp=sharing")
  PatientRisk<-as.data.frame(PatientRisk)
  
  #Set the date range, for testing purpose so set to 10 and 17, in exact, remove the 10, and change the 17 to 7
  start_date <- Sys.Date() - 7
  end_date <- Sys.Date()
  
  patientds <- patient
  #Filter the dataset only to display the last 7 days data
  patientds %>% filter((patient$date >= as.Date(start_date)),patient$date <= end_date)
  
  #provide the average of value for each parameters
  meandiatolic <- mean(patientds$diastolic)
  meansystolic <- mean(patientds$systolic)
  meancaloriesintake <- mean(patientds$caloriesintake)
  meancaloriesburnt <- mean(patientds$caloriesburnt)
  meanglucose <- mean(patientds$glucosereading)
  meanBMI <- mean(patientds$bmi)
  #render the value box to display blood pressure
  output$AvgBP <- renderValueBox({
    valueBox(
      formatC(sprintf("%s/ %s mmHg",format(round(meansystolic,1),nsmall = 0),round(meandiatolic,0)), format="d", big.mark=',')
      ,'Average Systolic last 7 days'
      ,icon = icon("tint",lib='glyphicon')
      ,color = "purple")  
  })
  
  #display the average BMI for last 7 days
  output$AvgBMI <- renderValueBox({
    valueBox(
      formatC(sprintf("%s BMI",format(round(meanBMI,1),nsmall=1)), format="d", big.mark=',')
      ,'Average BMI last 7 days'
      ,icon = icon("certificate",lib='glyphicon')
      ,color = "olive")  
  })
  
  #display the average blood glucose level for last 7 days
  output$Avgglucose <- renderValueBox({
    valueBox(
      formatC(sprintf("%s mmol/L",format(round(meanglucose,1),nsmall=1)), format="d", big.mark=',')
      ,'Average blood glucose level last 7 days'
      ,icon = icon("glass",lib='glyphicon')
      ,color = "blue")  
  })
  
  #display the average calories intake for last 7 days
  output$Avgcalintake <- renderValueBox({ 
    valueBox(
      formatC(sprintf("%s kcal",format(round(meancaloriesintake,1),nsmall=0)), format="d", big.mark=',')
      ,'kcal. Average Consumed Calories last 7 days'
      ,icon = icon("cutlery",lib='glyphicon')
      ,color = "green")  
  })
  
  #display the average calories burnt for last 7 days
  output$Avgcalburnt <- renderValueBox({
    valueBox(
      formatC(sprintf("%s kcal",format(round(meancaloriesburnt,1),nsmall=0)), format="d", big.mark=',')
      ,paste('Average Burnt Calories last 7 days')
      ,icon = icon("fire",lib='glyphicon')
      ,color = "yellow")   
  })
  
  
  #display the risk of heart attack
  output$RiskHeartAttackValue <- renderValueBox({
    valueBox(
     
      formatC(sprintf("%s risk",PatientRisk$Risk), format="d", big.mark=',')
      ,paste('in getting heart attack')
      ,icon = icon("heart",lib='glyphicon')
      ,color = PatientRisk$Color)   
  })

  
  observeEvent(input$submit1, {
    df<- createPersonalDataFrame(input)
    df<- updateFactors(df)
    heart<-predict(model, newdata = df)
    if(heart[1]=="Yes"){
      result<-data.frame(
        Risk="heigh",
        Color<-"red"
      )
    }
  else{
      result<-data.frame(
        Risk="low",
        Color="green"
      )
      personal <- gs4_get("https://docs.google.com/spreadsheets/d/12SCOAznYC0QYxmBgSsT7Fcz0XdtK_jo9NIKb8JtfBuY/edit?usp=sharing")
      range_write(personal,result,1,"A1:B")
      shinyalert(title=sprintf("Your heart disease risk is %s risk",result$Risk),
                 type="success",inputId = "success")
    }
    
    
  }) 
  

  observeEvent(input$submit2, {
    Daily_tracker <- gs4_get("https://docs.google.com/spreadsheets/d/1mZd4fmFSJR_tXQU_DBz5MWodmyu7TzrysYnC1vKkEzU/edit?usp=sharing")
    sheet_append(Daily_tracker, data = createDataFrame(input))
    shinyalert(title="Daily health information has saved",type="success",inputId = "success")
  }) 
  observeEvent(input$success, {
    session$reload()
  })
  
}